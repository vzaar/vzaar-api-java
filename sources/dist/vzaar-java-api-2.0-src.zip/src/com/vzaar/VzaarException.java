package com.vzaar;

public class VzaarException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = -7374361818811752534L;

    public VzaarException(String error) {
        super(error);
    }


}
