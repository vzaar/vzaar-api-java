package com.vzaar;

public class Profile {
    public static final int Small = 1;
    public static final int Medium = 2;
    public static final int Large = 3;
    public static final int HighDefinition = 4;
    public static final int Original = 5;
}
